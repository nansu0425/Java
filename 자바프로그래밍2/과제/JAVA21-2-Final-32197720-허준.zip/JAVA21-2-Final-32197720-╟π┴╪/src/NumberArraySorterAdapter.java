import java.util.List;

public class NumberArraySorterAdapter implements NumberListSorter {
	NumberArraySorter sorter;
	
	public NumberArraySorterAdapter(NumberArraySorter sorter) {
		super();
		this.sorter = sorter;
	}

	@Override
	public List<Integer> sort(List<Integer> numbers) {
		// TODO Auto-generated method stub
		return null;
	}

}
