import java.util.List;
//Java21-2 Final (2021/12/06 Kyoung Shin Park)

public interface NumberListSorter {
	List<Integer> sort(List<Integer> numbers);
}
