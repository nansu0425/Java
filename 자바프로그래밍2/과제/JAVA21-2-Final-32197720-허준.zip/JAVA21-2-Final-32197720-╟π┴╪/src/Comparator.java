//Java21-2 Final (2021/12/06 Kyoung Shin Park)
public interface Comparator<T> {
	int compare(T o1, T o2);
}
